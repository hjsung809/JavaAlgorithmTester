package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Arrays;

import tester.Executable;

public class _16198 implements Executable {
	static int n;
	static int[] arr;
	static boolean[] check;
	
	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		n = Integer.parseInt(br.readLine());
		arr = Arrays.stream(br.readLine().split(" "))
				.mapToInt(Integer::parseInt)
				.toArray();
		
		check = new boolean[n];
		bw.write(String.valueOf(search(0)));
		bw.close();
		br.close();
	}
	
	public static int search(int count) {
		int max = Integer.MIN_VALUE;
		if(count == n - 2) {
			return 0;
		}
		
		
		for(int i = 1; i < n - 1; i++) {
			if(!check[i]) {
				check[i] = true;
				int left = -1, right = -1;
				
				for(int j = i - 1; j >= 0; j--) {
					if(!check[j]) {
						left = j;
						break;
					}
				}
				for(int j = i + 1; j < n; j++) {
					if(!check[j]) {
						 right = j;
						 break;
					}
				}
				max = Math.max(max, arr[left] * arr[right] + search(count + 1));
				
				check[i] = false;
			}
		}
		
		return max;
	}

}

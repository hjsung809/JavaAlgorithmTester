package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Arrays;

import tester.Executable;

public class _10814 implements Executable {

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		br.readLine();
		br.lines()
			.map(s -> s.split(" "))
			.map(sa -> Arrays.stream(sa).map(se -> {return (Object)se;}).toArray())
			.peek(oa -> {oa[0] = (Integer)(Integer.parseInt((String)oa[0])); } )
			.sorted((a, b)-> (Integer)a[0] - (Integer)b[0])
			.forEach(oa -> {
				try {
					bw.write((Integer)oa[0] + " " + (String)oa[1] + "\n");
				} catch(Exception e) {
					throw new RuntimeException(e);
				}
			});
		bw.close();
		br.close();
	}

}

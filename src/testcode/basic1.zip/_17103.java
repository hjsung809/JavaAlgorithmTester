package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _17103 implements Executable{
	static boolean[] check;
	
	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		int n = Integer.valueOf(br.readLine());
		
		check = new boolean[1000001];
		calCheck();
		int[] arr = new int[n];
		for(int i = 0; i < n; i++) {
			arr[i] = Integer.parseInt(br.readLine());
			bw.write(String.valueOf(countPartition(arr[i])) + '\n' );
		}
		
		br.close();
		bw.close();
	}
	
	public static void calCheck() {
		check[0] = true;
		check[1] = true;
		for(int i = 3; i <= 1000000; i += 2) {
			if(!check[i]) {
				if(i < 1000) {
					for(int j = i*i; j <= 1000000; j += i) {
						check[j] = true;
					}					
				}
			}
		}
	}
	public static int countPartition(int num) {
		int count = 0;
		if(!check[2] && !check[num - 2]) {
			count++;
		}
		int i;
		for(i = 3; i <= num/2; i += 2) {
			if(!check[i] && !check[num - i]) {
				count++;
			}
		}
		return count;
	}
}

package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import tester.Executable;

public class _1978 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		int n = Integer.parseInt(br.readLine());
		int[] arr = new int[n];
		
		int max = 1;
		StringTokenizer st = new StringTokenizer(br.readLine());
		for(int i = 0; i < n; i++) {
			arr[i] = Integer.parseInt(st.nextToken());
			max = Math.max(max, arr[i]);
		}
		
		List<Integer> primary = new ArrayList<Integer>();
//		primary.add(1);
		boolean[] check = new boolean[max + 1];
		check[1] = true;
		
		for(int i = 2; i <= max; i++) {
			if(!check[i]) {
				primary.add(i);
				
				for(int j = 1; i * j <= max; j++) {
					check[i*j] = true;
				}
			}
		}
		
		int sol = 0;
		for(int i = 0; i < n; i++) {
			if(primary.contains(arr[i])) {
				sol++;
			}
		}
		
		bw.write(String.valueOf(sol));
		bw.close();
		br.close();
	}

}

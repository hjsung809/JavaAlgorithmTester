package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.Stack;
import java.util.StringTokenizer;

import tester.Executable;


public class _1918 implements Executable{

	static ArrayList<String> op_first = new ArrayList<>(Arrays.asList("*","/"));
	static ArrayList<String> op_second = new ArrayList<>(Arrays.asList("+","-"));
	static ArrayList<Character> op = new ArrayList<>(Arrays.asList('*','/','+','-','('));

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		Stack<String> stack = new Stack<>();
		Deque<String> deque = new ArrayDeque<String>();
		
		char[] str = br.readLine().toCharArray();

		for(int i = 0 ; i < str.length; i++) {
			
			if(str[i] == '(') {
				while(!deque.isEmpty()) {
					stack.push(deque.poll());
				}
				deque.add("(");
			} else if(str[i] == ')') {
				deque.add(")");
				String tmp = makeString(deque);
				
				while(!stack.isEmpty() && !stack.peek().equals("(")) {
					deque.addFirst(stack.pop());
				}
				if(!stack.isEmpty()) {
					deque.addFirst(stack.pop());
				}
				deque.add(tmp);
			} else {
				deque.add(String.valueOf(str[i]));
			}
		}
		
		while(!stack.isEmpty()) {
			deque.addFirst(stack.pop());
		}
		
		String string2 = makeString(deque);
//		System.out.println(string2);
		char[] str2 = string2.toCharArray();
		Stack<Character> stack2 =  new Stack<>();
		
		for(int i = 0; i < str2.length; i++) {
			if(str2[i] == ')') {
				while(stack2.peek() != '(') {
					bw.write(stack2.pop());
				}
				stack2.pop();
			}else if (op.contains(str2[i])) {
				stack2.add(str2[i]);
			} else {
				bw.write(str2[i]);
			}
		}
		while(!stack2.isEmpty()) {
			bw.write(stack2.pop());
		}
		
		br.close();
		bw.close();
	}
	
	public static String makeString(Deque<String> deque) {
		Deque<String> deque2 = new ArrayDeque<String>();
		
		while(!deque.isEmpty()) {
			String tmp = deque.poll();
			if(op_first.contains(tmp)) {
				String pre = deque2.pollLast();
				String back = deque.poll();
				deque2.add("(" + pre + tmp + back + ")");
			} else {
				deque2.add(tmp);
			}
		}
		
		while(!deque2.isEmpty()) {
			String tmp = deque2.poll();
			if(op_second.contains(tmp)) {
				String pre = deque.pollLast();
				String back = deque2.poll();
				deque.add("(" + pre + tmp + back + ")");
			} else {
				deque.add(tmp);
			}
		}
		
		StringBuffer sb = new StringBuffer();
		while(!deque.isEmpty()) {
			sb.append(deque.poll());
		}
		return sb.toString();
	}
}

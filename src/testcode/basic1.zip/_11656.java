package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;

import tester.Executable;

public class _11656 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		
		String str = br.readLine();
		String[] tmp = new String[str.length()];
		
		for(int i = 0 ; i < str.length(); i++) {
			tmp[i] = str.substring(i, str.length());
		}
		Arrays.sort(tmp);
		
		for(String sorted : tmp) {
			bw.write(sorted + "\n");
		}
		bw.close();
		br.close();
	}

}

package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

import tester.Executable;

public class _9465 implements Executable {

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		int t = Integer.parseInt(br.readLine());
		int n;
		int [][] arr;
		int [][] dp;
		
		for(int i = 0; i < t; i++) {
			n = Integer.parseInt(br.readLine());
			arr = new int [2][n + 1];
			dp = new int [2][n + 1];

			StringTokenizer st = new StringTokenizer(br.readLine());
			StringTokenizer st2 = new StringTokenizer(br.readLine());
			
			for(int j = 1; j <= n; j++) {	
				arr[0][j] = Integer.parseInt(st.nextToken());
				arr[1][j] = Integer.parseInt(st2.nextToken());
			}
			
			
			dp[0][1] = arr[0][1];
			dp[1][1]  = arr[1][1];
			
			for(int j = 2; j <= n; j++) {
				dp[0][j] = Math.max(dp[1][j - 1], dp[1][j - 2]) + arr[0][j];
				dp[1][j] = Math.max(dp[0][j - 1], dp[0][j - 2]) + arr[1][j];
			}
			
			int sol = Math.max(dp[0][n], dp[1][n]);
			bw.write(String.valueOf(sol) + '\n');
		}
		bw.close();
		br.close();
	}

}

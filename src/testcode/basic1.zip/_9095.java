package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _9095 implements Executable{
	
	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));;
		
		int t = Integer.parseInt(br.readLine());
		int[] n = new int[t];
		for(int i = 0 ; i < t; i++) {
			n[i] = Integer.parseInt(br.readLine());
		}
		
		int dp[] = new int[12];
		
		dp[0] = 0;
		dp[1] = 1;
		dp[2] = 2;
		dp[3] = 4;
		
		for(int i = 4; i <= 11; i++) {
			dp[i] = dp[i - 1] + dp[i - 2] + dp[i - 3];
		}
		
		for(int tmp : n) {
			bw.write(String.valueOf(dp[tmp]) + "\n");
		}

		bw.close();
		br.close();
	}
}

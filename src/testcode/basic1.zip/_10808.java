package testcode;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;

import tester.Executable;

public class _10808 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(in);
		
		char[] str = scanner.nextLine().toCharArray();
		int[] count = new int[26];
		
		for(char c : str) {
			count[c - 'a']++;
		}
		for(int c: count) {
			out.write(c + '0');
			out.write(' ');
		}
		
		
		out.flush();
		scanner.close();
	}
}

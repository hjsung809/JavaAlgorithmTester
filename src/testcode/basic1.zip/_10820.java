package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Arrays;

import tester.Executable;

public class _10820 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		ArrayList<Character> sLetter = new ArrayList<Character>();
		ArrayList<Character> lLetter = new ArrayList<Character>();
		for(int i = 0; i < 26; i ++) {
			sLetter.add((char)('a' + i));
			lLetter.add((char)('A' + i));
		}
		
		ArrayList<Character> digits = new ArrayList<Character>();
		for(int i = 0; i < 10; i ++) {
			digits.add((char)('0' + i));
		}
		
		int[] count = new int[4];

		
		for(String tmp = br.readLine(); tmp !=null; tmp = br.readLine()) {
			count = new int[4];
			for(int i = 0; i < tmp.length(); i ++) {
				char s = tmp.charAt(i);
				
				if(s == ' ') {
					count[3]++;
				} else if(digits.contains(s)){
					count[2]++;
				} else if(sLetter.contains(s)){
					count[0]++;
				} else if(lLetter.contains(s)){
					count[1]++;
				}
			}
			
			for(int c : count) {
				bw.write(c + " ");
			}
			bw.write("\n");
		}
		bw.flush();
	}
	
}

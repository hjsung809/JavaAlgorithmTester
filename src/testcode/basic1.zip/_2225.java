package testcode;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;

import tester.Executable;

public class _2225 implements Executable{
	

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(in);
		int n = sc.nextInt();
		int k = sc.nextInt();
		
		long[][] dp = new long[k + 1][n + 1];
		for(int i = 0; i <= n; i++) {
			dp[1][i] = 1;
		}
		
		for(int i = 2; i <= k; i++) {
			
			dp[i][0] = 1;
			for(int j = 1; j <= n; j++) {
//				for(int z = 0; z <= j; z++) {
//					dp[i][j] += dp[i - 1][z];
//				}
				dp[i][j] = (dp[i-1][j] + dp[i][j-1]) % 1000000000;
			}
		}
		
		out.write(String.valueOf(dp[k][n] ).getBytes());
		out.close();
		
		sc.close();
	}

}

package testcode;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;

import tester.Executable;

public class _1699 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(in);
		int n = sc.nextInt();
		int[] dp = new int[n+1];
//		int x = 100_100;
		
		dp[0] = 0;
		dp[1] = 1;
		for(int i = 2; i <=n; i++) {
			int min = Integer.MAX_VALUE;
			
			for(int m = (int)Math.sqrt(i); m > 0; m--) {
				min = Math.min(min, dp[i - m*m]);
			}
			dp[i] = min + 1;
		}
		
		out.write(String.valueOf(dp[n]).getBytes());
		out.flush();
		sc.close();
	}

}

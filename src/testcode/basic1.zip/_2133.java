package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _2133 implements Executable {

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		int n = Integer.parseInt(br.readLine());
		int[] dp = new int[31];
		
		dp[0] = 1;
//		dp[1] = 0;
		dp[2] = 3;
//		dp[3] = 0;

		
		for(int i = 4; i <= n; i += 2) {
			dp[i] = 3 * dp[i - 2];
			
			for(int j = 4; i - j >= 0; j += 2) {
				dp[i] += 2 * dp[i - j];
			}
//			System.out.println(dp[i]);
		}
		
		bw.write(String.valueOf(dp[n]));
		bw.close();
		br.close();
	}

}

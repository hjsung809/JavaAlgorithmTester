package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

import tester.Executable;

public class _13913 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		StringTokenizer st = new StringTokenizer(br.readLine());
		
		int n = Integer.valueOf(st.nextToken());
		int k = Integer.valueOf(st.nextToken());
		int[][] mark = new int[Math.max(2*k + 1, n+1)][2];
		
//		for(int i = 0; i < mark.length; i++) {
//			mark[i] = -1;
//		}
		
		Queue<Integer> q = new LinkedList<Integer>();
		q.add(n);
		mark[n][0] = 1; // 회차
		mark[n][1] = -1; // 지난 노
		
		int tmp = -1;

		while(!q.isEmpty()) {
			tmp = q.poll();
			if(tmp == k) break;
			
//			System.out.println(tmp);
			if (tmp < k && mark[tmp * 2][0] == 0) {
				q.add(tmp * 2);
				mark[tmp * 2][0] = mark[tmp][0] + 1;
				mark[tmp * 2][1] = tmp;
			}
			
			if (tmp < k && mark[tmp + 1][0] == 0) {
				q.add(tmp + 1);
				mark[tmp + 1][0] = mark[tmp][0] + 1;
				mark[tmp + 1][1] = tmp;
			}
			
			if(tmp - 1 >= 0 && mark[tmp -1][0] == 0) {
				q.add(tmp - 1);
				mark[tmp - 1][0] = mark[tmp][0] + 1;
				mark[tmp - 1][1] = tmp;
			}			
		}
//		System.out.println("End");
		
//		int count = 0;
		StringBuffer sb = new StringBuffer();
		sb.append(String.valueOf(tmp));
		
		while(mark[tmp][1] != -1) {
//			System.out.println(mark[tmp]);
			sb.insert(0, String.valueOf(mark[tmp][1]) + " ");
			tmp = mark[tmp][1];
//			count ++;
		}
		
		bw.write(String.valueOf(mark[k][0] - 1) + '\n');
		bw.write(sb.toString());
		bw.close();
		br.close();
	}

}

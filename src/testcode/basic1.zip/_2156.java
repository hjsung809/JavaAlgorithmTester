package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _2156 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		int n = Integer.valueOf(br.readLine());
//		int arrSize = Math.min(n+1, 3);
		int[] arr = new int[10001];
		int[] dp = new int[10001];
		for(int i = 1; i <=n; i++) {
			arr[i] = Integer.valueOf(br.readLine());
		}
		
		dp[1] = arr[1];
		dp[2] = arr[1] + arr[2];
		
		for(int i = 3; i <=n; i++) {
			dp[i] = Math.max(dp[i - 3] + arr[i - 1], dp[i - 2])+ arr[i];
			dp[i] = Math.max(dp[i], dp[i - 1]);
		}
		
//		for(int i = 1; i <=n; i++) {
//			System.out.println(dp[i]);
//		}
//		System.out.println();
		
		int sol = 0;
		for(int i = 1; i <=n; i++) {
			sol = Math.max(sol, dp[i]);
		}
		bw.write(String.valueOf(sol));
		br.close();
		bw.close();
	}

}

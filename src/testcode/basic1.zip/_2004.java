package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _2004 implements Executable{
	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		String[] nm = br.readLine().split(" ");
		int n = Integer.valueOf(nm[0]);
		int m = Integer.valueOf(nm[1]);
		int d = n - m;
		
		if(m == 0) {
			bw.write('0');
		} else {
			int five = getFive(n) - getFive(m) - getFive(d);
			int two = getTwo(n) - getTwo(m) - getTwo(d);
			five = Math.max(five, 0);
			two = Math.max(two, 0);
			bw.write(String.valueOf(Math.min(five, two)));
		}
		
		bw.close();
		br.close();
	}
	
	static int getFive(int num) {
		int count = 0;
		while (num >= 5) {
			count += num / 5;
			num /= 5;
		}
		return count;
	}
	
	static int getTwo(int num) {
		int count = 0;
		while (num >= 2) {
			count += num / 2;
			num /= 2;
		}
		return count;
	}
}

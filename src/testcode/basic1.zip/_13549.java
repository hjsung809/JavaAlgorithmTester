package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.LinkedList;
import java.util.Queue;

import tester.Executable;

public class _13549 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		String[] line = br.readLine().split(" ");
		int n = Integer.valueOf(line[0]);
		int k = Integer.valueOf(line[1]);
		int[] mark = new int[200001];
		
		Queue<Integer> q = new LinkedList<Integer>();
		mark[n] = 1;
		q.add(n);
		
		boolean find = false;
		int tmp = -1;
		int tmp2 = -1;
		
		while(!q.isEmpty()) {
			tmp = q.poll();
			if(tmp == k) break;
			
			tmp2 = tmp;
			while(tmp2 < k && mark[2*tmp2] == 0) {
				q.add(2*tmp2);
				mark[2*tmp2] = mark[tmp2];	
				tmp2 *= 2;
			}
			
			
			if(tmp < k && mark[tmp + 1] == 0) {
				q.add(tmp + 1);
				mark[tmp + 1] = mark[tmp] + 1;
			}
			
			if(tmp > 0 && mark[tmp - 1] == 0) {
				q.add(tmp - 1);
				mark[tmp - 1] = mark[tmp] + 1;
			}
		}
		
		bw.write(String.valueOf(mark[tmp] - 1));
		bw.close();
		br.close();
	}

}

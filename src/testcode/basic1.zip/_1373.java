package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _1373 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		StringBuilder sb = new StringBuilder();
		String str = br.readLine();
		int i;
		for(i = str.length() - 1; i >= 2; i -= 3) {
			int num = Integer.parseInt(str.substring(i - 2, i + 1), 2);
			sb.insert(0, Integer.toString(num, 8));
		}
		
		if(i >= 0) {
			int num = Integer.parseInt(str.substring(0, i + 1), 2);
			sb.insert(0, Integer.toString(num, 8));
		}
		
		bw.write(sb.toString());
		bw.close();
		br.close();
	}

}

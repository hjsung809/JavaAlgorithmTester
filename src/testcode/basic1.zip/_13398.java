package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

import tester.Executable;

public class _13398 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		int n = Integer.parseInt(br.readLine());
		int[] arr = new int[n];
		int[][] dp = new int [n][2];
		
		StringTokenizer st = new StringTokenizer(br.readLine());
		for(int i = 0; i < n; i++) {
			arr[i] = Integer.parseInt(st.nextToken());
		}
		
		dp[0][0] = arr[0]; // 점프 하지 않은 경우
		dp[0][1] = arr[0]; // 점프 한 경우
		int jumped = 0;
		
		for(int i = 1; i < n; i++) {
			dp[i][0] = Math.max(dp[i - 1][0] + arr[i], arr[i]);
			dp[i][1] = Math.max(dp[i - 1][1] + arr[i], dp[i - 1][0]);
			
//			if(dp[i -1][0] > 0) {
//				dp[i][0] = dp[i - 1][0] + arr[i];
//			}else {
//				dp[i][0] = arr[i];
//			}
//			dp[i][0] = dp[i - 1][0] > 0 ? dp[i - 1][0] + arr[i] : arr[i];
			
			// 최대한 큰 수를 점프할것임.
			// 점프한 한뒤에, 이어갈 의미가 있어야함.
//			if(arr[i] < jumped) {
//				if(dp[i -1][0] > 0) {
//					dp[i][1] = dp[i-1][0];
//					jumped = arr[i];
//				} else {
//					dp[i][1] = dp[i][0];
//					jumped = 0;
//				}
//			} else {
//				if(dp[i-1][1] > 0) {
//					dp[i][1] = dp[i -1][1] + arr[i];
//				} else {
//					// 점프가 의미없으므로, 재시작
//					dp[i][1] = dp[i][0];
//					jumped = 0;
//				}
//			}
		}
		
		int sol = Integer.MIN_VALUE;
		for(int i = 0; i < n; i++) {
//			System.out.println(dp[i][0] + "," + dp[i][1]);
			sol = Math.max(sol, dp[i][0]);
			sol = Math.max(sol, dp[i][1]);
		}
//		System.out.println();
		bw.write(String.valueOf(sol));
		br.close();
		bw.close();
	}

}

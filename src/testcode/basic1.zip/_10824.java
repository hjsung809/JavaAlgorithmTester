package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

import tester.Executable;

public class _10824 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		StringTokenizer st = new StringTokenizer(br.readLine());
		String[] arr = new String[4];
		for(int i = 0 ; i < arr.length; i++) arr[i] = st.nextToken();
		
		long result = Long.parseLong(arr[1]) + Long.parseLong(arr[3]);
		result += Long.parseLong(arr[0]) * Math.pow(10, arr[1].length());
		result += Long.parseLong(arr[2]) * Math.pow(10, arr[3].length());
		
		bw.write(String.valueOf(result));
		bw.flush();
	}
}

package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Stack;
import java.util.StringTokenizer;

import tester.Executable;

public class _17299 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		int n = Integer.parseInt(br.readLine());
		
		int[] a = new int[n];
		int[] ngf = new int[n];
		HashMap<Integer, Integer> f = new HashMap<Integer, Integer>();
		Stack<Integer> stack = new Stack<>();
		
		StringTokenizer st = new StringTokenizer(br.readLine());
		for(int i = 0; i < n; i++) {
			int token = Integer.parseInt(st.nextToken());
			a[i] = token;
			ngf[i] = -1;
			
			if(f.containsKey(token)) {
				int pre = f.get(token);
				f.replace(token, pre + 1);
			} else {
				f.put(token, 1);
			}
		}
		
		stack.add(0);
		for(int i = 1; i < n; i ++) {
			while(!stack.isEmpty() && f.get(a[stack.peek()]) < f.get(a[i])){
				ngf[stack.pop()] = a[i];
			}
			stack.add(i);
		}
		
		for(int tmp : ngf) {
			bw.write(String.valueOf(tmp) +" ");
		}
		
		bw.flush();
		bw.close();
		br.close();
	}

}

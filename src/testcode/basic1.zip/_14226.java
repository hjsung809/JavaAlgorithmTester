package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.LinkedList;
import java.util.Queue;

import tester.Executable;

public class _14226 implements Executable {

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		int[][] mask = new int [2001][1001];
		Queue<int[]> q = new LinkedList<int[]>();
		
		int n = Integer.valueOf(br.readLine());
		q.add(new int[] {1, 0});
		mask[1][0] = 1;
		
		int[] tmp = null;
		while(!q.isEmpty()) {
			tmp = q.poll();
//			System.out.println(tmp);
			if(tmp[0] == n) break;
			
			// 복사
			if(tmp[0] < 1000 && tmp[1] < 500 && mask[tmp[0]][tmp[0]] == 0) {
				mask[tmp[0]][tmp[0]] = mask[tmp[0]][tmp[1]] + 1;
				q.add(new int[] {tmp[0], tmp[0]});
			}
			
			// 붙여넣기
			if(tmp[0] < 1000 && mask[tmp[0] + tmp[1]][tmp[1]] == 0) {
				mask[tmp[0] + tmp[1]][tmp[1]] = mask[tmp[0]][tmp[1]] + 1;
				q.add(new int[] {tmp[0] + tmp[1], tmp[1]});
			}
			
			// 빼기
			if(tmp[0] > 0 && mask[tmp[0] - 1][tmp[1]] == 0) {
				mask[tmp[0] - 1][tmp[1]] = mask[tmp[0]][tmp[1]] + 1;
				q.add(new int[] {tmp[0] - 1, tmp[1]});
			}
		}
//		System.out.println("answer:" + mask[tmp[0]][tmp[1]]);
//		System.out.println();
		bw.write(String.valueOf(mask[tmp[0]][tmp[1]] - 1));
		bw.close();
		br.close();
	}

}

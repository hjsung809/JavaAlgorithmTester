package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

import tester.Executable;

public class _13460 implements Executable {
	static int n, m;
	static char[][] arr;
	static int holeX, holeY;
	int redMX = 0, redMY = 0;
	int blueMX = 0, blueMY = 0;
	static boolean[] directions = new boolean[4];

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));

		String tmp = br.readLine();
		StringTokenizer st = new StringTokenizer(tmp);
		n = Integer.parseInt(st.nextToken());
		m = Integer.parseInt(st.nextToken());

		arr = new char[n][m];
		int redX = 0, redY = 0;
		int blueX = 0, blueY = 0;

		for (int i = 0; i < n; i++) {
			tmp = br.readLine();

			for (int j = 0; j < m; j++) {
				arr[i][j] = tmp.charAt(j);
				if (arr[i][j] == 'R') {
					redX = j;
					redY = i;
					arr[i][j] = '.';
				} else if (arr[i][j] == 'B') {
					blueX = j;
					blueY = i;
					arr[i][j] = '.';
				} else if (arr[i][j] == 'O') {
					holeX = j;
					holeY = i;
					arr[i][j] = '.';
				}
			}
		}

		int result = dfs(redX, redY, blueX, blueY, 0);
		bw.write(String.valueOf(result));
		bw.close();
		br.close();
	}

	private int dfs(int redX, int redY, int blueX, int blueY, int trial) {
		if (trial > 10)
			return -1;
		
		// 4방향으로 이동하면서 답이 있는지,없는다 확인한다.
		// 이동된 좌값을 가지고 있는다.
		// 답이 있으면 정답 리턴.
		
		
		// 답이 있으면 리턴한다.
		
		// 답이 없으면 리커시브하게 호출한다.
		move();
		move();
		move();		
		move();
		
		
		// 4방향으로 움직이고 재귀함수 호출.
		// 답을 리턴 받으면
		
		return -1;
	}

	private boolean canMove(int x1, int y1, int x2, int y2, int dy, int dx) {
		return arr[y1 + dy][x1 + dx] == '.' && (x1 + dx != x2 || y1 + dy != y2);
	}
	
	// 1: 성공 0: 계속 -1: 실패
	private int move() {
		
		return 0;
	}
}

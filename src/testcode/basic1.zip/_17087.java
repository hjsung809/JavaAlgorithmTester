package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Arrays;
import java.util.StringTokenizer;

import tester.Executable;

public class _17087 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		String[] ns = br.readLine().split(" ");
		int n = Integer.parseInt(ns[0]);
		int s = Integer.parseInt(ns[1]);
		
		int[] brother = new int[n + 1];
		brother[0] = s;
		
		StringTokenizer st = new StringTokenizer(br.readLine());
		for(int i = 1; i <= n; i++) {
			brother[i] = Integer.parseInt(st.nextToken());
		}
		Arrays.sort(brother);
		
		int[] gap = new int[n];
		for(int i = 0; i < n; i++) {
			gap[i] = brother[i+1] - brother[i];
		}
		Arrays.sort(gap);
		
		int sol = gap[0];
		for(int i = 1; i < n; i++) {
			sol = gcd(sol, gap[i]);
		}
		bw.write(String.valueOf(sol));
		bw.close();
		br.close();
	}
	
	private static int gcd(int num1, int num2) {
//		a 와 b의 최소 공약수는
//		a % b = c 일때,
//		b 와 c의 최소 공약수와 같다.
		int max = Math.max(num1, num2);
		int min = Math.min(num1, num2);
		int tmp = max % min;
		
		while(tmp != 0) {
			max = min;
			min = tmp;
			tmp = max % min;
		}
		return min;
	}

}

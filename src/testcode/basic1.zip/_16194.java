package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

import tester.Executable;

public class _16194 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		int n = Integer.parseInt(br.readLine());
		int[] p = new int[n + 1];
		int[] dp = new int[n + 1];
		
		StringTokenizer st = new StringTokenizer(br.readLine());
		for(int i = 1 ; i <= n; i++) {
			p[i] = Integer.parseInt(st.nextToken());
		}
		
		dp[1] = p [1];
		int min;
		for(int i = 2; i <=n; i++) {
			min = p[i];
			
			for(int j = i - 1; j > (i-1)/2; j--) {
				min = Math.min(min, dp[j] + dp[i -j]);
			}
			dp[i] = min;
		}
		
		bw.write(String.valueOf(dp[n]));
		bw.close();
		br.close();
	}

}

package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

import tester.Executable;

public class _11054 implements Executable {

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		int n = Integer.parseInt(br.readLine());
		int[] arr = new int[1000];
		int[][] dp = new int[1000][2];
		

		
		StringTokenizer st = new StringTokenizer(br.readLine());
		for(int i = 0; i < n; i++) {
			arr[i] = Integer.parseInt(st.nextToken());
		}
		
		int sol = 1;
		dp[0][0] = 1;
		dp[0][1] = 1;
		
		for(int i = 1; i < n; i++) {
			dp[i][0] = 1;
			dp[i][1] = 1;
			
			for(int j = 0; j < i; j++) {
				if(arr[i] > arr[j]) { // 증가하는 부분일때.
					dp[i][0] = Math.max(dp[i][0], dp[j][0] + 1);
					
				} else if(arr[i] < arr[j]){
					dp[i][1] = Math.max(dp[i][1], dp[j][1] + 1); 
					dp[i][1] = Math.max(dp[i][1], dp[j][0] + 1); 
				}
			}
			
			sol = Math.max(sol, dp[i][0]);
			sol = Math.max(sol, dp[i][1]);
		}
		
		
		bw.write(String.valueOf(sol));
		bw.close();
		br.close();
	}

}

package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.LinkedList;
import java.util.Queue;
import java.util.StringTokenizer;

import tester.Executable;

public class _1697 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		StringTokenizer st = new StringTokenizer(br.readLine());
		int n = Integer.parseInt(st.nextToken());
		int k = Integer.parseInt(st.nextToken());
		boolean success = false;
		

		boolean[] mark = new boolean[2*k + 1];
		Queue<Integer> current = new LinkedList<Integer>();
		Queue<Integer> store = new LinkedList<Integer>();
		Queue<Integer> tmp;
		int count = 0;
		
		if(n > k) {
			success = true;
			bw.write(String.valueOf(n - k));
		} else {
			mark[n] = true;
			current.add(n);
		}

		while(!success) {
			
			while(!current.isEmpty()) {
				int target = current.poll();
				
				if (target == k) {
					bw.write(String.valueOf(count));
					success = true;
					break;
				}
				
				if(target < k && !mark[target+1]) {
					mark[target + 1] = true;
					store.add(target + 1);		
				}
				
				if(target > 1 && !mark[target - 1]) {
					mark[target - 1] = true;
					store.add(target - 1);	
				}
	
				if(target < k && !mark[target * 2]) {
					mark[target * 2] = true;
					store.add(target * 2);				
				}
			}
			
			tmp = store;
			store = current;
			current = tmp;
			count++;
		}
		
		bw.close();
		br.close();
	}
}

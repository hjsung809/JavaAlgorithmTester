package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.LinkedList;
import java.util.Stack;
import java.util.StringTokenizer;

import tester.Executable;

public class _17298 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		int n = Integer.parseInt(br.readLine());
		int[] a = new int[n];
		int[] nge = new int[n];

//		LinkedList<Integer> list = new LinkedList<>();
//		Stack<Integer> front = new Stack<>();
		Stack<Integer> back = new Stack<>();
		
		
		StringTokenizer st = new StringTokenizer(br.readLine());
		for(int i = 0; i < n; i++) {
			a[i] = Integer.parseInt(st.nextToken());
		}
		
		for(int i = n-1; i >=0; i--) {
			
			while(!back.isEmpty() && back.peek() <= a[i]) {
				back.pop();
//				front.push();
			}
			
			if(back.isEmpty()) {
				nge[i] = -1;
			} else {
				nge[i] = back.peek();
			}
			back.push(a[i]);
		}
		
		for(int i = 0 ; i < n ; i++) {
			bw.write(String.valueOf(nge[i]) + " ");
		}
		
		bw.flush();
		bw.close();
		br.close();
	}

}

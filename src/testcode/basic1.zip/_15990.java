package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _15990 implements Executable{
	private static long MOD = 1;

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		MOD *= 1000;
		MOD *= 1000;
		MOD *= 1000;
		MOD += 9;
		
		int t = Integer.parseInt(br.readLine());
		int[] n = new int[t];
		int max = 0;
		
		for(int i = 0 ; i < t; i++) {
			n[i] = Integer.parseInt(br.readLine());
			max = Math.max(max, n[i]);
		}
//		long[] dp2 = new long[max + 1];
		long[][] dp = new long[max + 1][3];
		
		dp[1][0] = 1;
		dp[1][1] = 0;
		dp[1][2] = 0;
//		dp2[1] = 1;
		
		dp[2][0] = 0;
		dp[2][1] = 1;
		dp[2][2] = 0;
//		dp2[2] = 1;
		
		dp[3][0] = 1;
		dp[3][1] = 1;
		dp[3][2] = 1;
//		dp2[3] = 3;
		
		
		for(int i = 4; i <= max; i++) {
//			dp2[i] = dp2[i - 1] + dp2[i-3] - dp2[i-4] - dp2[i -6];
			dp[i][0] = dp[i - 1][1] + dp[i - 1][2]; // 2 - 1 = 1
			dp[i][1] = dp[i - 2][0] + dp[i - 2][2]; // 1 - 1 = 0
			dp[i][2] = dp[i - 3][0] + dp[i - 3][1]; // 1 - 0 = 1
			
			if(dp[i][0] > MOD) dp[i][0] = dp[i][0] % MOD;
			if(dp[i][1] > MOD) dp[i][1] = dp[i][1] % MOD;
			if(dp[i][2] > MOD) dp[i][2] = dp[i][2] % MOD;
		}
		
		for(int i : n) {
			bw.write(String.valueOf((dp[i][0] + dp[i][1] + dp[i][2]) % MOD) + "\n");
		}
		bw.close();
		br.close();
	}

}

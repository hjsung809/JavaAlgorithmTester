package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _1676 implements Executable {

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		int n = Integer.parseInt(br.readLine());
		
		int two = 0;
		int five = 0;
		
		if(n == 0) {
			bw.write('0');
		}else {
//			long sol = 1;
			int tmp;
			for(int i = n; i > 0; i--) {
				tmp = i;
				
				while((tmp & 1) != 1) {
					tmp >>= 1;
					two++;
				}
				
				while(tmp % 5 == 0) {
					tmp /= 5;
					five++;
				}
			}
			
			bw.write(String.valueOf(Math.min(two, five)));
		}
		bw.close();
		br.close();
	}

}

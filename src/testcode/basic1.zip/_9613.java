package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

import tester.Executable;

public class _9613  implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		int t = Integer.parseInt(br.readLine());
		for(int i = 0; i < t; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			int n = Integer.parseInt(st.nextToken());
			long sol = 0;
			int[] arr = new int[n];
			
			for(int j = 0; j < n; j++) {
				arr[j] = Integer.parseInt(st.nextToken());
			}
			
			for(int j = 0; j < n; j++) {
				for(int k = j + 1; k < n; k++) {
					sol += gcd(arr[j], arr[k]);
				}
			}
			
			bw.write(String.valueOf(sol) + '\n');
		}
		
//		System.out.println(gcd(12,20));
		bw.close();
		br.close();
	}
	
	private static int gcd(int num1, int num2) {
//		a 와 b의 최소 공약수는
//		a % b = c 일때,
//		b 와 c의 최소 공약수와 같다.
		int max = Math.max(num1, num2);
		int min = Math.min(num1, num2);
		int tmp = max % min;
		
		while(tmp != 0) {
			max = min;
			min = tmp;
			tmp = max % min;
		}
		return min;
	}
}

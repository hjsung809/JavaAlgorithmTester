package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.text.DecimalFormat;
import java.util.Stack;
import java.util.StringTokenizer;

import tester.Executable;

public class _1935 implements Executable{
	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		int n = Integer.parseInt(br.readLine());
		int[] nums = new int[n];
		char[] str = br.readLine().toCharArray();
		
		for(int i = 0 ; i < n ; i++) {
			nums[i] = Integer.parseInt(br.readLine());
//			System.out.print(nums[i]);
		}
//		System.out.println();
		
		Stack<Double> stack = new Stack<>();
		for(int i = 0; i < str.length; i++) {
			if(str[i] >= 'A' && str[i] <= 'Z') {
				stack.add(nums[str[i] - 'A'] + 0.0);
			}else {
				Double back = stack.pop();
				Double front = stack.pop();
				
				switch(str[i]) {
				case '+':
					stack.push(front + back);
					break;
				case '-':
					stack.push(front - back);
					break;
				case '*':
					stack.push(front * back);
					break;
				case '/':
					stack.push(front / back);
					break;
				}
			}
//			System.out.println(stack.peek());
		}
		bw.write(new DecimalFormat("0.00").format(stack.pop()));
		br.close();
		bw.close();
	}
}

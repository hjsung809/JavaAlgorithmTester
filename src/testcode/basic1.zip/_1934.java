package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

import tester.Executable;

public class _1934 implements Executable{
	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		int n = Integer.parseInt(br.readLine());
		
		for(int i = 0 ; i < n ; i++) {
			StringTokenizer st = new StringTokenizer(br.readLine());
			int A = Integer.parseInt(st.nextToken());
			int B = Integer.parseInt(st.nextToken());
			bw.write(String.valueOf(A*B/gcd(A,B)) + "\n");
		}
		
		br.close();
		bw.close();
	}
	
	public static int gcd(int A, int B) {
		int big, small;
		big = Math.max(A, B);
		small = Math.min(A, B);
		int R = big % small;
		
		while(R != 0) {
			big = small;
			small = R;
			R = big % small;
		}
		return small;
	}
}

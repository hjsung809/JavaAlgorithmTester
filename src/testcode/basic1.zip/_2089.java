package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _2089 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		int n = Integer.valueOf(br.readLine());
		StringBuilder sb = new StringBuilder();
		
		System.out.println((-13 - 1)/-2);
		System.out.println(-13%-2);
		
		
		while(n != 0) {
			if(n % -2 == 0) {
				sb.insert(0, '0');
				n /= -2;
			} else {
				sb.insert(0, '1');
				n = (n-1)/ -2;
			}
		}
		
		if(sb.length() > 0) {
			bw.write(sb.toString());			
		} else {
			bw.write("0");
		}

		bw.close();
		br.close();
	}

}

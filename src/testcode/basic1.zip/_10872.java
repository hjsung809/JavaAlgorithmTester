package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _10872 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		int n = Integer.parseInt(br.readLine());
		
		if(n == 0) {
			bw.write('1');
		}else {
			int sol = 1;
			for(int i = n; i > 0; i--) {
				sol *= i;
			}
			bw.write(String.valueOf(sol));
		}
		bw.close();
		br.close();
	}

}

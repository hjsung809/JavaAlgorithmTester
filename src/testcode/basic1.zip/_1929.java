package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import tester.Executable;

public class _1929 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		String[] mn = br.readLine().split(" ");
		int m = Integer.parseInt(mn[0]);
		int n = Integer.parseInt(mn[1]);
		
		List<Integer> primary = new ArrayList<Integer>();
		boolean[] check = new boolean[n + 1];
		check[0] = true;
		check[1] = true;
		
		for(int i = 2; i <= n; i++) {
			if(!check[i]) {
				if(i >= m) {
					primary.add(i);					
				}

				if(i < Math.sqrt(n)) {
					for(int j = i*i; j <= n; j += i) {
						check[j] = true;
					}
				}	
			}
		}
		
		for(int p : primary) {
//			System.out.println(p);
			bw.write(String.valueOf(p));
			bw.write('\n');
		}
		bw.close();
		br.close();
	}


}

package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _1309 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		int n = Integer.valueOf(br.readLine());
		int arrSize = Math.max(n + 1, 3);
		int[] dp = new int[arrSize];
		
		dp[1] = 3;
		dp[2] = 7;
		
		for(int i = 3; i <= n; i++) {
			dp[i] = (2 * dp[i - 1] + dp[i - 2]) % 9901;
		}
		
		bw.write(String.valueOf(dp[n]));
		bw.close();
		br.close();
	}

}

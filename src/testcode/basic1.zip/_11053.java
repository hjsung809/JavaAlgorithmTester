package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.PriorityQueue;
import java.util.StringTokenizer;

import tester.Executable;

public class _11053 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		int n = Integer.parseInt(br.readLine());
		StringTokenizer st = new StringTokenizer(br.readLine());
		
		int[] a = new int[n];
		int[] dp = new int[n];
		for(int i = 0 ; i < n; i ++) {
			a[i] = Integer.parseInt(st.nextToken());
		}
		

		dp[0] = 1;
		
		for(int i = 1; i < n; i++) {
			int val = 1;
			for(int j = 0; j < i; j++) {
				if(a[j] < a[i]) {
					val = Math.max(val, dp[j] + 1);
				}
			}	
			dp[i] = val;
			
		}
		
		int solution = 0;
		for(int i = 0; i < n; i++) {
			solution = Math.max(solution, dp[i]);
		}
		
		bw.write(String.valueOf(solution));
		bw.close();
		br.close();
	}

}

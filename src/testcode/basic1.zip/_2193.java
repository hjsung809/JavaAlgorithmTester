package testcode;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;

import tester.Executable;

public class _2193 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(in);
		int n = sc.nextInt();
		long[][] dp = new long[n + 1][2];
		dp[1][0] = 0;
		dp[1][1] = 1;
		
		for(int i = 2; i <= n; i++) {
			dp[i][0] = dp[i - 1][0] + dp[i - 1][1];
			dp[i][1] = dp[i - 1][0];
		}
		
		
		out.write(String.valueOf(dp[n][0] + dp[n][1]).getBytes());
		out.close();
		sc.close();
	}

}

package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _11655 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		char[] str = br.readLine().toCharArray();
		
		for(int i = 0; i < str.length; i++) {
			if (str[i] >= 'a' && str[i] <= 'z'){
				bw.write((str[i] - 'a' + 13)%26 + 'a');
			} else if (str[i] >= 'A' && str[i] <= 'Z'){
				bw.write((str[i] - 'A' + 13)%26 + 'A');
			} else {
				bw.write(str[i]);
			}
		}
		bw.flush();
	}

}

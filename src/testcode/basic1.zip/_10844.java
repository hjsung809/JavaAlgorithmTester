package testcode;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;

import tester.Executable;

public class _10844 implements Executable{
	private static long MOD = 1000 * 1000* 1000;

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(in);
		int n = sc.nextInt();
		long[][] dp = new long[n + 1][10];
		
		for(int i = 0; i < 10; i++) {
			dp[1][i] = 1;
		}
		dp[1][0] = 0;
		
		
		for(int i = 2; i <=n; i++) {
			dp[i][1] += dp[i - 1][0];
			dp[i][8] += dp[i - 1][9];
			for(int j = 1; j < 9; j ++) {
				dp[i][j - 1] += dp[i-1][j];
				dp[i][j + 1] += dp[i-1][j];
			}
			
			for(int j = 0; j <= 9; j ++) {
				if(dp[i][j] >=  MOD)  dp[i][j] = dp[i][j] % MOD;
			}
		}
		
		long answer = 0;
		for(int j = 0; j <= 9; j ++) {
			answer += dp[n][j];
			if(answer >=  MOD) answer = answer % MOD;
		}
		
		out.write((String.valueOf(answer) + "\n").getBytes());
		out.flush();
		
	}

}

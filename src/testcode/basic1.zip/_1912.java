package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

import tester.Executable;

public class _1912 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		int n = Integer.parseInt(br.readLine());
		StringTokenizer st = new StringTokenizer(br.readLine());
		
//		int[] a = new int [n];
//		int[] dp = new int[n];
//		for(int i = 0; i < n; i++) {
//			a[i] = Integer.parseInt(st.nextToken());
//		}
//		
//
//		dp[0] = a[0];
//		int sol = dp[0];
//		
//		for(int i = 1; i < n; i++) {
//			if(dp[i - 1] > 0) {
//				dp[i] = dp[i - 1] + a[i];
//			} else {
//				dp[i] = a[i];
//			}
//			sol = Math.max(sol, dp[i]);
//		}
		
		
		int pre = Integer.parseInt(st.nextToken());
		int sol = pre;
		
		for(int i = 1; i < n; i++) {
			int tmp = Integer.parseInt(st.nextToken());
			
			if(pre > 0) pre += tmp;
			else pre = tmp;
			
			sol = Math.max(sol, pre);
		}

		bw.write(String.valueOf(sol));
		
		br.close();
		bw.close();
	}

}

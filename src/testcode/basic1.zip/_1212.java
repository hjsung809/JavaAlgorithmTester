package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _1212 implements Executable {

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		char[] str = br.readLine().toCharArray();
		StringBuilder sb = new StringBuilder();
		
		int tmp;
		for(int i = 0; i < str.length; i++) {
			tmp = str[i] - '0';
			
			sb.append((tmp & 4) >> 2);
			sb.append((tmp & 2) >> 1);
			sb.append(tmp & 1);
		}
		
		while(sb.charAt(0) == '0' && sb.length() > 1) {
			sb.deleteCharAt(0);
		}
		bw.write(sb.toString());
		
		br.close();
		bw.close();
	}

}

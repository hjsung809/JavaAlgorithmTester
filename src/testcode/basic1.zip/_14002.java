package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.StringTokenizer;

import tester.Executable;

public class _14002 implements Executable{

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		int n = Integer.parseInt(br.readLine());
		StringTokenizer st = new StringTokenizer(br.readLine());
		
		int[] a = new int[n];
		int[][] dp = new int[n][2];
		for(int i = 0 ; i < n; i ++) {
			a[i] = Integer.parseInt(st.nextToken());
		}
		

		dp[0][0] = 1;
		dp[0][1] = -1;
		
		for(int i = 1; i < n; i++) {
			dp[i][1] = -1;
			
			int val = 1;
			for(int j = 0; j < i; j++) {
				if(a[j] < a[i] && val < dp[j][0] + 1) {
					val = dp[j][0] + 1;
					dp[i][1] = j;
				}
			}	
			dp[i][0] = val;
		}
		
		int solution = 0;
		int solIdx = 0;
		for(int i = 0; i < n; i++) {
			if(solution < dp[i][0]) {
				solution = dp[i][0];
				solIdx = i;
			}
		}
		
		
		bw.write(String.valueOf(solution) + "\n");
		StringBuilder sb = new StringBuilder();
		sb.append(a[solIdx]+ " ");
//		bw.write(a[solIdx]+ " ");
		
		int idx = solIdx;
		while(dp[idx][1] != -1) {
//			bw.write(a[dp[idx][1]] + " ");
			sb.insert(0, a[dp[idx][1]] + " ");
			idx = dp[idx][1];
		}
		bw.write(sb.toString());
		
		bw.close();
		br.close();
	}

}

package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.List;

import tester.Executable;

public class _6588 implements Executable {

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		
		List<Integer> inputList = new ArrayList<Integer>();
		while(true) {
			int input = Integer.valueOf(br.readLine());
			
			if(input == 0) break;
			else inputList.add(input);
		}
		
		boolean[] check = new boolean[1000001];
		check[0] = true;
		check[1] = true;
		
		List<Integer> primary = new ArrayList<Integer>();
		for(int i = 2; i <= 1000000; i++) {
			if(!check[i]) {
				primary.add(i);
				
				if(i < 1000) {
					for(int j = i*i; j <= 1000000; j += i) {
						check[j] = true;
					}
				}
			}
		}
		
		StringBuilder sb = new StringBuilder();
		for(int i : inputList) {
			for(int p : primary) {
				if(!check[i - p]) {
					sb.append(i).append(" = ").append(p).append(" + ").append(i-p).append('\n');
					break;
				}
			}
		}
		
		bw.write(sb.toString());
		br.close();
		bw.close();
	}

}

package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.PriorityQueue;

import tester.Executable;

public class _1261 implements Executable{
	static int m;
	static int n;
	static int[][] arr;
	static int[][] value;
	
	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		String[] mn = br.readLine().split(" ");
		
		m = Integer.valueOf(mn[0]);
		n = Integer.valueOf(mn[1]);
		
		arr = new int[n][m];
		value = new int[n][m];
		for(int i = 0; i < n; i++) {
			String line = br.readLine();
			for(int j = 0 ; j < m; j++) {
				arr[i][j] = line.charAt(j) - '0';
				value[i][j] = Integer.MAX_VALUE;
			}
		}		
		value[0][0] = 0;
		
		PriorityQueue<int[]> pq = new PriorityQueue<int[]>((a,b) -> {
			if(a[2] == b[2]) {
				return value[a[0]][a[1]] - value[b[0]][b[1]];
			}
			return a[2] - b[2];
		});
		// 0 = y, 1 = x, 2 = 0 or 1.
		
		pq.add(new int[] {0, 0, 0});
		int[] tmp;
		int[] dx = {-1, 1, 0 ,0 };
		int[] dy = { 0, 0, -1 ,1 };
		
		while(value[n-1][m-1] == Integer.MAX_VALUE) {
			tmp = pq.poll();

			for(int i = 0; i < 4; i++) {
				if(
						tmp[0] + dy[i] >= 0 &&
						tmp[0] + dy[i] < n &&
						tmp[1] + dx[i] >= 0 &&
						tmp[1] + dx[i] < m &&
						value[tmp[0] + dy[i]][tmp[1] + dx[i]] == Integer.MAX_VALUE
					) {
					value[tmp[0] + dy[i]][tmp[1] + dx[i]] = value[tmp[0]][tmp[1]] + arr[tmp[0] + dy[i]][tmp[1] + dx[i]];
					pq.add(new int[] {tmp[0] + dy[i], tmp[1] + dx[i], arr[tmp[0] + dy[i]][tmp[1] + dx[i]]});
				}
			}
		}
		bw.write(String.valueOf(value[n-1][m-1]));		
		bw.close();
		br.close();
	}
}

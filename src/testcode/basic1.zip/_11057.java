package testcode;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import tester.Executable;

public class _11057 implements Executable {

	@Override
	public void main(InputStream in, OutputStream out) throws Exception {
		// TODO Auto-generated method stub
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(out));
		int n = Integer.valueOf(br.readLine());
		
		int[][] dp = new int[n+1][10];
		for(int i = 0; i <= 9; i++) {
			dp[1][i] = 1;
		}
		
		for(int i = 2; i <= n; i++) {
			dp[i][0] = 1;
			for(int j = 1; j <= 9; j++) {
				dp[i][j] = (dp[i][j - 1] + dp[i - 1][j]) % 10007;
			}
		}
		
		int sol = 0;
		for(int i = 0; i <=9; i++) {
			sol = (sol + dp[n][i]) % 10007;
		}
		
		bw.write(String.valueOf(sol));
		bw.close();
		br.close();
	}
}
